/*
 *	  Copyright (C) 2022  John H. Gaby
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, version 3 of the License.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *    Contact: robotics@gabysoft.com
 */

#ifdef __cplusplus
extern "C" {
#endif

extern int initializeCamera(int shutterSpeed, int gain);
extern int captureImage(unsigned char * out_buffer, int out_buffer_size);
extern int setShutterSpeed(int speed);
extern int setGain(int gain);

#ifdef __cplusplus
}
#endif
