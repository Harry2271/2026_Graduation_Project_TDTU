var searchData=
[
  ['supply_5fvoltage_5fmax_0',['SUPPLY_VOLTAGE_MAX',['../driver__ina226_8c.html#a68eba8b601afe11f1b871d944976c035',1,'driver_ina226.c']]],
  ['supply_5fvoltage_5fmin_1',['SUPPLY_VOLTAGE_MIN',['../driver__ina226_8c.html#aac8d8cbd899667d609787ef4cf37054d',1,'driver_ina226.c']]]
];
