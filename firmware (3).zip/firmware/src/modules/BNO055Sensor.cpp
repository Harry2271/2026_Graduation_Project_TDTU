#include "BNO055Sensor.h"
#include <Arduino.h>
#include <Wire.h>

extern "C" {
#include "bno055.h"

// I2C transport — implemented in bno055_wire_support.cpp
s8 BNO055_I2C_bus_write(u8 dev_addr, u8 reg_addr, u8 *reg_data, u8 cnt);
s8 BNO055_I2C_bus_read(u8 dev_addr, u8 reg_addr, u8 *reg_data, u8 cnt);
void BNO055_delay_msek(u32 msek);
}

static struct bno055_t gs_bno;
static bool gs_bno_inited = false;

BNO055Sensor::BNO055Sensor()
    : heading_deg_(0.0f), heading_error_deg_(0.0f)
    , target_heading_deg_(0.0f), has_target_(false)
    , linear_accel_x_(0.0f), linear_accel_y_(0.0f)
    , gyro_z_dps_(0.0f)
    , temperature_(0)
    , cal_sys_(0), cal_gyro_(0), cal_accel_(0), cal_mag_(0)
    , operational_(false), addr_(0x28), last_read_ms_(0)
{
}

bool BNO055Sensor::begin(uint8_t address)
{
    addr_ = address;

    // Wire is already begun in setupHardware(). Just probe.
    Wire.beginTransmission(addr_);
    if (Wire.endTransmission() != 0) {
        Serial.printf("[BNO055] No device at 0x%02X\n", addr_);
        return false;
    }

    // --- Set up Bosch bno055 driver I2C function pointers ---
    gs_bno.bus_write = BNO055_I2C_bus_write;
    gs_bno.bus_read  = BNO055_I2C_bus_read;
    gs_bno.delay_msec = BNO055_delay_msek;
    gs_bno.dev_addr  = addr_;

    // Initialise the Bosch driver (reads chip ID, sw rev, etc.)
    s8 res = bno055_init(&gs_bno);
    if (res != BNO055_SUCCESS) {
        Serial.printf("[BNO055] bno055_init failed (%d)\n", res);
        return false;
    }

    // Verify chip ID
    u8 chip_id = 0;
    bno055_read_chip_id(&chip_id);
    if (chip_id != 0xA0) {
        Serial.printf("[BNO055] Unexpected chip ID: 0x%02X\n", chip_id);
        return false;
    }
    Serial.printf("[BNO055] Chip ID OK: 0x%02X\n", chip_id);

    // Switch to CONFIG mode before setting power / operation mode
    bno055_set_operation_mode(BNO055_OPERATION_MODE_CONFIG);
    delay(BNO055_CONFIG_MODE_SWITCHING_DELAY);

    // Normal power
    bno055_set_power_mode(BNO055_POWER_MODE_NORMAL);
    delay(10);

    // Set clock source to external oscillator (bit 7 of SYS_TRIGGER)
    u8 clk = 1;
    bno055_set_clk_src(clk);

    // Use degrees, m/s², °/s, Celsius
    // BNO055 unit sel register 0x3B:
    //   bit 0: accel = m/s² (0)
    //   bit 1: gyro  = °/s  (0)
    //   bit 2: euler = degrees (0)
    //   bit 4: temp   = Celsius (0)
    // Defaults are already correct — no write needed.

    // Enter NDOF fusion mode (absolute orientation, all 9 axes)
    bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
    delay(BNO055_MODE_SWITCHING_DELAY);

    gs_bno_inited = true;
    operational_ = true;
    Serial.printf("[BNO055] Ready — NDOF mode, addr 0x%02X\n", addr_);
    return true;
}

bool BNO055Sensor::read()
{
    if (!operational_ || !gs_bno_inited) return false;
    last_read_ms_ = millis();

    // --- Euler angles (degrees) ---
    double euler_h = 0.0, euler_r = 0.0, euler_p = 0.0;
    bno055_convert_double_euler_h_deg(&euler_h);
    bno055_convert_double_euler_r_deg(&euler_r);
    bno055_convert_double_euler_p_deg(&euler_p);

    float heading = (float)euler_h;
    if (heading < 0.0f)  heading += 360.0f;
    if (heading >= 360.0f) heading -= 360.0f;
    heading_deg_ = heading;

    // --- Heading error: target − current, normalised to ±180° ---
    if (has_target_) {
        float err = target_heading_deg_ - heading_deg_;
        // Normalise to (-180, 180]
        if (err > 180.0f)  err -= 360.0f;
        if (err <= -180.0f) err += 360.0f;
        heading_error_deg_ = err;
    } else {
        heading_error_deg_ = 0.0f;
    }

    // --- Linear acceleration (m/s²) ---
    double la_x = 0.0, la_y = 0.0;
    bno055_convert_double_linear_accel_x_msq(&la_x);
    bno055_convert_double_linear_accel_y_msq(&la_y);
    linear_accel_x_ = (float)la_x;
    linear_accel_y_ = (float)la_y;

    // --- Gyro Z (°/s) ---
    double gz = 0.0;
    bno055_convert_double_gyro_z_dps(&gz);
    gyro_z_dps_ = (float)gz;

    // --- Temperature (°C) ---
    s8 temp_raw = 0;
    bno055_read_temp_data(&temp_raw);
    temperature_ = temp_raw;

    // --- Calibration ---
    u8 cs = 0, cg = 0, ca = 0, cm = 0;
    bno055_get_sys_calib_stat(&cs);
    bno055_get_gyro_calib_stat(&cg);
    bno055_get_accel_calib_stat(&ca);
    bno055_get_mag_calib_stat(&cm);
    cal_sys_   = cs;
    cal_gyro_  = cg;
    cal_accel_ = ca;
    cal_mag_   = cm;

    return true;
}

float BNO055Sensor::getHeadingRad() const
{
    return heading_deg_ * DEG_TO_RAD;
}

void BNO055Sensor::setTargetHeading(float target_deg)
{
    target_heading_deg_ = target_deg;
    has_target_ = true;
}

void BNO055Sensor::printTelemetry() const
{
    Serial.printf("{\"type\":134,\"data\":{"
                  "\"heading\":%.2f,"
                  "\"heading_error\":%.2f,"
                  "\"linear_accel_x\":%.2f,"
                  "\"linear_accel_y\":%.2f,"
                  "\"gyro_z\":%.2f,"
                  "\"temp\":%d,"
                  "\"cal\":{\"sys\":%u,\"gyro\":%u,\"accel\":%u,\"mag\":%u}"
                  "}}\n",
                  heading_deg_, heading_error_deg_,
                  linear_accel_x_, linear_accel_y_,
                  gyro_z_dps_,
                  temperature_,
                  cal_sys_, cal_gyro_, cal_accel_, cal_mag_);
}

void BNO055Sensor::printReadable() const
{
    Serial.printf("Heading: (%.2f deg)\n", heading_deg_);
    Serial.printf("Heading Error: (%.2f deg)\n", heading_error_deg_);
    Serial.printf("Linear Accel X: (%.2f m/s2)\n", linear_accel_x_);
    Serial.printf("Linear Accel Y: (%.2f m/s2)\n", linear_accel_y_);
    Serial.printf("Gyro Z: (%.2f deg/s)\n", gyro_z_dps_);
    Serial.printf("Temp: %d C\n", temperature_);
    Serial.printf("Cal: sys=%u gyro=%u accel=%u mag=%u\n",
                  cal_sys_, cal_gyro_, cal_accel_, cal_mag_);
}