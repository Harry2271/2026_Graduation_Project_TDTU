# Archive

## Week of 2026-06-16
ESP32-S3 development stabilized across multiple issues: aligned BNO055 calibration naming with trailing-underscore conventions, fixed missing initializer in main.cpp, disabled GPIO 2 LED via direct write. IR proximity obstacle-avoidance refactored to trigger on state changes only. FR motor hardware fault diagnosed. Upload failures on WeAct ESP32-S3 resolved 2026-07-04 by adding `--before no_reset` and `board_upload.use_1200bps_touch = true` to platformio.ini, compensating for missing DTR/RTS auto-reset circuit.